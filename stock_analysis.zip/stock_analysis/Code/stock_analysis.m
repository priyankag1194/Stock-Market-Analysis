%ECE - 529 Digital Signal Processing - Project
%By - Priyanka Goswami
%----------------------------------------------------------------
%The following code analyses stock prices of a company and 
%predicts the closing price.
%The algorithms implemented for predicting closing price are:
%(a)Kalman Filter   (b)Kalman Multiple Linear Regression
%The algorithms implemented for analysing the trends in a stock
%(c) Bollinger bands (d). Chaikin Oscillator
%Output - 1. Graphs showing the predicted and actual values of 
%closing price of stock anlong with bollinger bands
%2. The chaikin oscillator graph 
%3. %accuracy of prediction of Kalman and MLR filter
%------------------------------------------------------------------

%Load .mat file having stock data
str = input('Enter filename:');

%Run algorithms
load (str);
run('kalman1.m')

load (str);
run('bollinger.m')

load (str);
run('multiple_linear_regress.m')

load (str);
run('chaikin.m')

%Plot output graphs for analysis
y=1:200;
load (str);
x_close = z(:,4);
x_close=x_close';
x_close = fliplr(x_close);
x_close = x_close(1:200);
plot(y,x_close,'k',y,x_kalman,'r',y,x_mlr,'g',y,x_ma_m,'c',y,x_ma_u,'b',y,x_ma_l,'b')
title('Overall Comparison for Stock');
xlabel('No. of Days - N');
ylabel('Closing Prices');
legend('Actual Price','Kalman','MLR','MA, K=20','Bollinger Upper/Lower band','Location','northwest')

%Calculating prediction accuracy for Kalman and Multiple Linear Regression
%(MLR)
kal=0;
mlr=0;
%Calculating the difference between predicted and actual close price daily
for j=1:200
    t_k(j) = abs(x_close(j)-x_kalman(j));    
     t_m(j) = abs(x_close(j)-x_mlr(j));
end

%taking mean of the difference

k_mean = mean(t_k)
m_mean = mean(t_m)
%If for any day the diff. betwen predicted and actual is less than the
%mean then it is selected as correct prediction
for j=1:200
    if (t_k(j) < k_mean)   
        kal=kal+1;
    end
     if (t_m(j) < k_mean)
        mlr=mlr+1;
     end
end
   Accuracy_Kalman = (kal/(m-1-f_size))*100
   Accuracy_MLR = (mlr/(m-1-f_size))*100
    
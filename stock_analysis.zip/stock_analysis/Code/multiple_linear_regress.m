%ECE - 529 Digital Signal Processing - Project
%By - Priyanka Goswami
%----------------------------------------------------------------
%Multiple Linear Regression - 
%Using open and high predict close prices
% filename1 = 'Data/appl_comb.mat';
% ---------------------------------------------------------------

% load(filename1);
x1=z(:,1);%open price
x2=z(:,2);%high price
y=z(:,3);
s=z(:,4); %close price

X = [ones(size(x1)) x1 x2 x1.*x2]; %Generate predictors
b=regress(y,X); %coefficients of filter generated using response Y and predictor X
y_predict = b(1) + b(2)*x1 + b(3)*x2 + b(4)*x1.*x2; %Using filter to calculate closing price

% For plotting graph and curve 
% x1fit = x1(1:50);
% x2fit = x2(1:50);
% scatter3(x1fit,x2fit,y_predict(1:50),'filled')
% hold on
% [X1FIT,X2FIT] = meshgrid(x1fit,x2fit);
% YFIT = b(1) + b(2)*X1FIT + b(3)*X2FIT + b(4)*X1FIT.*X2FIT;
% mesh(X1FIT,X2FIT,YFIT)
% title ('Multiple Linear Regression - Curve for Stock 1'); 
% xlabel('Open')
% ylabel('High')
% zlabel('Close')
% figure
% [m,l]=size(z);
% n=1:m;
% s=s';
% s=fliplr(s);
y_predict = y_predict';
y_predict = fliplr(y_predict);

% plot(n,s,'k',n,y_predict,'r')
% title('Multiple Linear Regression - Stock 1');
% xlabel('No. of Days - N');
% ylabel('Closing Prices');
% legend('Actual Price','Predicted Price','Location','northwest')
% figure

%For analysis
x_mlr = y_predict(1:200);




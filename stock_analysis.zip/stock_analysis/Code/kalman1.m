%ECE - 529 Digital Signal Processing - Project
%By - Priyanka Goswami
%----------------------------------------------------------------
%KALMAN FILTER -
%Predict closing price of a stock
%For Kalman Filter - 
% A = 1, B = 0.83
%P'(1) variance of closing prices, x'(1) = avg. of closing prices
%-----------------------------------------------------------------

% filename = 'Data\appl_comb.mat';
% load(filename);

z=z(:,4)'; %load closing price 
z=fliplr(z);

z=[0,z];
[m,n]=size(z);

x=zeros(size(z));
x(1)= mean(z);

p = zeros(size(z));
p(1)=var(z);

R=0.00013;

A=1;    %quantization interval
B = 0.83;
for k = 2:n
    
     %time update (prediction)
        
        xt(k)= A*x(k-1)+B*(z(k)-z(k-1));
        pt(k)= A*p(k-1);
        
        %Measurement update (correction)
        H(k) = (pt(k))/(pt(k)+R);
        
        x(k) = xt(k)+H(k)*(z(k)-xt(k));
        
        p(k)=(1-H(k))* pt(k);
        
      
end

%Plot Actual and Predicted Closing Proces for a stock
% z(1)=[];
% x(1)=[];
% y=1:n-1;
% plot(y,z,'k',y,x,'r');
% title('Kalman Filter - Stock 1');
% xlabel('No. of Days - N');
% ylabel('Closing Prices');
% legend('Actual Price','Predicted Price','Location','southeast')
% figure

%For analysis
x_kalman = x(1:200);

        




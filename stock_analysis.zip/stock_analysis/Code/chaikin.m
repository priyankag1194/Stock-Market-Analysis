%ECE - 529 Digital Signal Processing - Project
%By - Priyanka Goswami
%----------------------------------------------------------------
%Chaikin Oscillator
%predict the future performance of a stock 
%----------------------------------------------------------------

x_h=z(:,2); %High
x_h=fliplr(x_h);
x_l=z(:,3); %Low
x_l=fliplr(x_l);
x_c=z(:,4);%Close
x_c=fliplr(x_c);
x_v=z(:,5);%Volume
x_v=fliplr(x_v);
[m,n]=size(z);
a_d = zeros(m,1);

%Computing the Accumulation/Distribution line

for k=1:m
    a_d(k,1) = (((x_c(k,1) - x_l(k,1))-(x_h(k,1) - x_c(k,1)))/(x_h(k,1)-x_l(k,1)))*x_v(k,1);
end

%plotting the oscillator and actual closing price
chosc = chaikosc(x_h,x_l,x_c,x_v);
y=1:m;
j=zeros(m,1);
subplot(2,1,1)
plot(y,j,'k',y,a_d,'.-.c',y,chosc,'b');
title('Chaikin Oscillator - Stock 1');
xlabel('No. of Days - N');
legend('A/D','Chaikin Osc.','Location','northeast')
hold on;
subplot(2,1,2)
plot(y,x_c,'k');
title('Closing Prices - Stock 1');
xlabel('No. of Days - N');
ylabel('Close prices');
figure
%Moving avaerage filter
%average of n-k days to predict the closing price of the stock on day n.  
%For the analysis, different values of k were used like 5, 10, 15 and 20.

filename1=('Data/appl_comb');
load(filename1);
z=z(:,4);
z=z';
z=fliplr(z);
[m,n]=size(z);

%Moving avaerage filter
ma =5;  %Filter Size
for k = ma+1:n
    temp1 = sum(z(k-ma:k-1));   %Sum of elments
    z_5(k) = temp1/ma;  %Computing Average
end

ma =10;

for k = ma+1:n
    temp1 = sum(z(k-ma:k-1));
    z_10(k) = temp1/ma;
end

ma =15;

for k = ma+1:n
    temp1 = sum(z(k-ma:k-1));
    z_15(k) = temp1/ma;
end

ma =20;

for k = ma+1:n
    temp1 = sum(z(k-ma:k-1));
    z_20(k) = temp1/ma;
end
z=z(ma:n);
z_5 = z_5(ma:n);
z_10=z_10(ma:n);
z_15 = z_15(ma:n);
z_20 = z_20(ma:n);
y=1:n-ma+1;

plot(y,z,'k',y,z_5,y,z_10,y,z_15,y,z_20);
title ('Moving Avg Filter - Stock 2');
xlabel('No. of Days - N');
ylabel('Closing Prices');
legend('Actual Price','K=5','K=10','K=15','K=20')



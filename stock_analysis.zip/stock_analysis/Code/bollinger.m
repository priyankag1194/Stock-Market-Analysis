%ECE - 529 Digital Signal Processing - Project
%By - Priyanka Goswami
%----------------------------------------------------------------
%Bollinger Bands
%For observing the volatility
%-----------------------------------------------------------------
% str = input('Enter filename:');
% load (str);
x_c=z(:,4); %Load close-price

x_c=x_c';   % Input - closing price of a stock
x_c = fliplr(x_c);
[m,n]=size(x_c);
f_size =20; %n=20 for moving avg. filter
K=2;    %2 periods above the standard deviation
s=std(x_c); %Standard deviation of the closing prices

for i = f_size+1:n
    temp1 = sum(x_c(i-f_size:i-1));
    ma_m(i-f_size) = temp1/f_size;  %calculating the middle band
    ma_u(i-f_size) = ma_m(i-f_size)+K*s; %Calculating the upper band
    ma_l(i-f_size) = ma_m(i-f_size)-K*s;%Calculating the lower band
end

%For plotting Bands
% y=1:n-f_size;
% x_c=x_c(f_size+1:n);
% plot(y,x_c,'k',y,ma_m,'r',y,ma_u,'b',y,ma_l,'b');
% title ('Bollinger Band - Stock 1');
% xlabel('No. of Days - N');
% ylabel('Closing Prices');
% legend('Actual Price','Middle Band','Upper Band/Lower Band','location','northwest')
%figure

%For Analysis
x_ma_m = ma_m(1:200);
x_ma_u = ma_u(1:200);
x_ma_l = ma_l(1:200);